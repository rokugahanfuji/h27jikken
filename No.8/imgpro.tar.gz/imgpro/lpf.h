#define WINDOW 4
#define MAX_TAP 64

void lp_filter(Image image_in, Image image_out, double fx, double fy);
