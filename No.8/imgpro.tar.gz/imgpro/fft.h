#define EXH	7
#define EXV	7
#define MAX	255

void fft2(double a_rl[][X_SIZE], double a_im[][X_SIZE], int exh, int exv, int inv, double *sin_tbl, double *cos_tbl);
